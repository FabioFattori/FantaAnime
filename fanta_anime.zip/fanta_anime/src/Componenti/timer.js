import React, { useState, useEffect } from "react";

function Timer({ maxRange }) {
  const [Count, setCount] = useState(maxRange);

  useEffect(() => {
    console.log(Count);
    if (Count > 0) {
      setTimeout(() => setCount(Count - 1), 1000);
    }
  }, [Count]);

  return <span>{Count}</span>;
}

export default Timer;
