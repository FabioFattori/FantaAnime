import React from "react";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import img from "../img/profilePicDefault.png";
import Image from "react-bootstrap/Image";
import "./CssComponenti/NavBar.css";

import { useHistory } from "react-router-dom";

function NavigationBar() {
  const History = useHistory();

  return (
    <Navbar sticky="top" bg="light" expand="lg">
      <Container>
        <Navbar.Brand>FantaAnime</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link onClick={()=>{History.push("About")}}>About</Nav.Link>
            <Nav.Link onClick={()=>{History.push("CreaLega")}}>Crea Lega</Nav.Link>

            <div className="profilePic">
              <Image onClick={()=>{History.push("Profilo")}} width="7%" src={img} roundedCircle />
            </div>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavigationBar;
