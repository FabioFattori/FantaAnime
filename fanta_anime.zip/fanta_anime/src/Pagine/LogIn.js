import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import "./CssPagine/Login.css";
import { useHistory } from "react-router-dom";

function LogIn() {
  const History = useHistory();

  const [Email, SetEmail] = useState("");
  const [Pass, SetPass] = useState("");

  function controllaSeLaStringaContiene(stringa, char) {
    for (let index = 0; index < stringa.length; index++) {
      if (stringa[index] === char) {
        return true;
      }
    }

    return false;
  }

  function CheckInput() {
    if (Email === "" || Pass === "") {
      alert("inserisci le variabili");
    } else if (Pass < 5) {
      alert("la password deve essere lunga almeno 5 caratteri");
    } else if (Email.endsWith("@")) {
    } else if (!controllaSeLaStringaContiene(Email, "@")) {
    } else {
      History.push("/Home");
    }
  }

  return (
    <div className="LoginContent">
      <h3 className="Title">Login</h3>

      <Form>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <div className="Description">
            <Form.Label>Email address</Form.Label>
          </div>

          <Form.Control
            type="email"
            value={Email}
            onChange={(event) => SetEmail(event.target.value)}
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <div className="Description">
            <Form.Label>Password</Form.Label>
          </div>

          <Form.Control
            type="password"
            value={Pass}
            onChange={(event) => SetPass(event.target.value)}
          />
        </Form.Group>

        <Form.Group className="mb-3">
          {/* eslint-disable-next-line jsx-a11y/anchor-is-valid */}
          <a className="Link" onClick={() => History.push("/Registrazione")}>
            Non sei Registrato? Clicca qui!
          </a>
        </Form.Group>

        <Button variant="primary" type="submit" onClick={() => CheckInput()}>
          Loggati!
        </Button>
      </Form>
    </div>
  );
}

export default LogIn;
