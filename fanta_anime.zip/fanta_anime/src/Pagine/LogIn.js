import React from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import "./CssPagine/Login.css";
import { useHistory } from "react-router-dom";

function LogIn() {
  const History = useHistory();

  return (
    <div className="LoginContent">
      <h3 className="Title">Login</h3>

      <Form>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <div className="Description">
            <Form.Label>Email address</Form.Label>
          </div>

          <Form.Control  type="email"  />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <div className="Description">
            <Form.Label>Password</Form.Label>
          </div>

          <Form.Control type="password"  />
        </Form.Group>

        <Form.Group className="mb-3">
          {/* eslint-disable-next-line jsx-a11y/anchor-is-valid */}
          <a className="Link" onClick={() => History.push("/Registrazione")}>
            Non sei Registrato? Clicca qui!
          </a>
        </Form.Group>

        <Button
          variant="primary"
          type="submit"
          onClick={() => History.push("/Home")}
        >
          Loggati!
        </Button>
      </Form>
    </div>
  );
}

export default LogIn;
