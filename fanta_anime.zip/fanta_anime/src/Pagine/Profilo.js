import React, { useState } from "react";
import Card from "react-bootstrap/Card";
import ListGroup from "react-bootstrap/ListGroup";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import "./CssPagine/Profilo.css";
import Button from "react-bootstrap/Button";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Form from "react-bootstrap/Form";
import { useHistory } from "react-router-dom";
import CardGroup from "react-bootstrap/CardGroup";

function Profilo() {
  const History = useHistory();
  const [graficaColonnaDestra, setColonna] = useState(null);

  //variabile che contiene email, password, nome utente e la possibilità di modificare quest'ultime
  let datiProfilo = (
    <div>
      <Card style={{ width: "auto" }}>
        <Card.Img variant="top" src="" />
        <Card.Body>
          <Card.Title>I tuoi Dati</Card.Title>
        </Card.Body>
        <ListGroup className="list-group-flush">
          <ListGroup.Item>
            <div className="Row">
              <p>cambia immagine profilo</p>
            </div>
          </ListGroup.Item>
          <ListGroup.Item>
            <div className="Row">
              <Form>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                  <Form.Label className="Scritta">Nickname</Form.Label>
                  <Form.Control placeholder="Nick" />
                </Form.Group>
              </Form>
            </div>
          </ListGroup.Item>
          <ListGroup.Item>
            <div className="Row">
              <Form>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                  <Form.Label className="Scritta">Email</Form.Label>
                  <Form.Control type="email" placeholder="email" />
                </Form.Group>
              </Form>
            </div>
          </ListGroup.Item>
          <ListGroup.Item>
            <div className="Row">
              <Form>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                  <Form.Label className="Scritta">Password</Form.Label>
                  <Form.Control type="password" placeholder="pass" />
                </Form.Group>
              </Form>
            </div>
          </ListGroup.Item>
        </ListGroup>
      </Card>
      <div className="Row-Buttons">
        <Button variant="primary" className="SaveChanges" size="sm">
          Salva Modifiche
        </Button>
        <Button variant="primary" size="sm">
          Logout
        </Button>
      </div>
    </div>
  );

  let legheInCorso = (
    <ListGroup>
      <ListGroup.Item action>lega in corso1</ListGroup.Item>
      <ListGroup.Item action>lega in corso2</ListGroup.Item>
      <ListGroup.Item action>lega in corso3</ListGroup.Item>
    </ListGroup>
  );

  let legheConcluse = (
    <ListGroup>
      <ListGroup.Item action>lega conclusa1</ListGroup.Item>
      <ListGroup.Item action>lega conclusa2</ListGroup.Item>
      <ListGroup.Item action>lega conclusa3</ListGroup.Item>
    </ListGroup>
  );

  return (
    <div>
      <Navbar bg="light" expand="lg">
        <Container>
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link
                onClick={() => {
                  History.push("Home");
                }}
              >
                Home
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <div className="ProfileContent">
        <Row>
          <Col sm={2}>
            <ListGroup>
              <ListGroup.Item
                action
                onClick={() => {
                  setColonna(datiProfilo);
                }}
              >
                Profilo
              </ListGroup.Item>
              <ListGroup.Item action disabled>
                Le tue leghe
              </ListGroup.Item>
              <ListGroup.Item
                action
                onClick={() => {
                  setColonna(legheInCorso);
                }}
              >
                in corso
              </ListGroup.Item>
              <ListGroup.Item
                action
                onClick={() => {
                  setColonna(legheConcluse);
                }}
              >
                concluse
              </ListGroup.Item>
            </ListGroup>
          </Col>
          <Col sm={10}>{graficaColonnaDestra}</Col>
        </Row>
      </div>
    </div>
  );
}

export default Profilo;
