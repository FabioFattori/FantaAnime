import React from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import "./CssPagine/Reg.css";
import { useHistory } from "react-router-dom";

function Registrazione() {
  const History = useHistory();

  return (
    <div className="RegContent">
      <h3 className="Title">Registrazione</h3>

      <Form>
        <Form.Group className="mb-3" >
          <div className="Description">
            <Form.Label>Nickname</Form.Label>
          </div>

          <Form.Control type="text" placeholder="per esempio: sushiLover88" />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicEmail">
          <div className="Description">
            <Form.Label>Email address</Form.Label>
          </div>

          <Form.Control type="email" placeholder="inserisci la tua email" />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <div className="Description">
            <Form.Label>Password</Form.Label>
          </div>

          <Form.Control type="password" placeholder="Password" />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <div className="Description">
            <Form.Label>Conferma Password</Form.Label>
          </div>

          <Form.Control type="password" placeholder="Conferma" />
        </Form.Group>

        <Form.Group className="mb-3">
          {/* eslint-disable-next-line jsx-a11y/anchor-is-valid */}
          <a className="Link" onClick={() => History.push("/")}>
            Possiedi già un account? Clicca qui!
          </a>
        </Form.Group>

        <Button
          variant="primary"
          type="submit"
          onClick={() => History.push("/Home")}
        >
          Registrati!
        </Button>
      </Form>
    </div>
  );
}

export default Registrazione;
