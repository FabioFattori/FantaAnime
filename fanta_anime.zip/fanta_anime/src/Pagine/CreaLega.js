import React from 'react'

function CreaLega() {
  return (
    <div>CreaLega</div>
  )
}

export default CreaLega