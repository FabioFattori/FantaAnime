import React from "react";
import "./CssPagine/About.css";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import { useHistory } from "react-router-dom";
import ReAnime from "../img/logoReanime.png";
import Fabio from "../img/Fabio.JPG"
import Brando from "../img/brando.png"

function About() {
  const History = useHistory();

  return (
    <div>
      <Navbar expand="lg">
        <Container>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link
                onClick={() => {
                  History.push("Home");
                }}
              >
                Home
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <h1 className="Titolo">About Us!</h1>
      <h9 className="Paragrafo">
        Siamo due ragazzi usciti dall'istituto{" "}
        <a
          className="Link"
          href="https://www.ispascalcomandini.it/"
          target="blank"
        >
          Istituto Superiore Pascal Comandini
        </a>{" "}
        ai quali è stato chiesto di realizzare questo applicativo da parte di .
      </h9>
      <div className="Raccolta">
        <div className="DescrizioneConImmagineADestra">
          <div className="Scritte">
            <p className="Nome">Tommaso Brandinelli</p>
            <p className="Lavoro">Ideatore del lato Back-End </p>
          </div>
          <img className="ImmaginePersona" src={Fabio} alt="Pic" />
        </div>
        
      </div>
      <div className="Raccolta">
        <div className="DescrizioneConImmagineASinistra">
          <div className="Scritte">
            <p className="Nome">Fattori Fabio</p>
            <p className="Lavoro">Creatore del Front-End dell'applicativo</p>
          </div>
          <img className="ImmaginePersona" src={Fabio} alt="Pic" />
        </div>
        
      </div>
      <div className="Raccolta">
        <div className="DescrizioneConImmagineADestra">
          <div className="Scritte">
            <p className="Nome">ReAnimee</p>
            <p className="Lavoro">Partner twitch, creatore dell'idea</p>
          </div>
          <img className="ImmaginePersona" src={ReAnime} alt="Pic" />
        </div>
        
      </div>
    </div>
  );
}

export default About;
