import React from 'react'
import Navigation from '../Componenti/Navbar'

function Home() {
  return (
    <div>
      <Navigation />
    </div>
  )
}

export default Home