import "./App.css";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import Reg from "./Pagine/Registrazione";
import LogIn from "./Pagine/LogIn";
import Home from "./Pagine/Home";
import About from "./Pagine/About";
import CreaLega from "./Pagine/CreaLega";
import Profilo from "./Pagine/Profilo";

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Switch>
        <Route path="/About">
            <About />
          </Route>
          <Route path="/Profilo">
            <Profilo />
          </Route>
          <Route path="/CreaLega">
            <CreaLega />
          </Route>
        <Route path="/Home">
            <Home />
          </Route>
        <Route path="/Registrazione">
            <Reg />
          </Route>
          <Route path="/">
            <LogIn />
          </Route>
          <Route path="*">
            <div>
              <h1>ERRORE 404</h1>
            </div>
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
